self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "923c4109eeafe4017ea3539cfac56395",
    "url": "./index.html"
  },
  {
    "revision": "4e6d20004f6188ab30dc",
    "url": "./static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "34fdff9630dfd2c0e1e9",
    "url": "./static/css/main.439b4a20.chunk.css"
  },
  {
    "revision": "4e6d20004f6188ab30dc",
    "url": "./static/js/2.1c5dcafb.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.1c5dcafb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "34fdff9630dfd2c0e1e9",
    "url": "./static/js/main.249e6a28.chunk.js"
  },
  {
    "revision": "0367ed5c2b578b0fc6ba",
    "url": "./static/js/runtime-main.04b5d81b.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);